# mk_TextMining_final

Matt, Jordan, & Kanning's Text Mining Project.
