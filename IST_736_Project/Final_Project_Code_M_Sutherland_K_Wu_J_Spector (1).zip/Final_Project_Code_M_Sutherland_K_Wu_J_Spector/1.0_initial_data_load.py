#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Dec  6 13:17:41 2020

@author: msutherland
"""
'''Libraries'''
#Data Analysis
import pandas as pd

#Visualizations

get_it_done = pd.read_csv('get_it_done_2020_ALL.csv') #all 311 requests to date 1/1/2020 -> 12/5/2020
