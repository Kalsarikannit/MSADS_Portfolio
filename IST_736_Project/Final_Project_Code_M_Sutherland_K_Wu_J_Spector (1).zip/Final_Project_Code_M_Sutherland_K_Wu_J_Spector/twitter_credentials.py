#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Matt & Kanning's'
Twitter Credentials
"""


# Consume:
CONSUMER_KEY    = 'KjMe6EsGefDd8oHqTg7DxCCtk'
CONSUMER_SECRET = 'XWvKWVpQNfFAAsQPcDnBSy2bfChl1uhqMex8rYjYPINWuxQIfV'

# Access:
ACCESS_TOKEN  = '994026943107551232-9TVxktVEPgfiK8tlJP0R2l49G6LT8qo'
ACCESS_SECRET = 'kls9A3nQ0yQvALgCNX6Tb5HJ9Vc4kupKH7IXnve316GGa'